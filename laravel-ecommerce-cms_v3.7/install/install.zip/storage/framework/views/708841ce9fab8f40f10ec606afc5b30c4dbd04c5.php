<?php
	echo $array['content'];
?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/emails/newsletter.blade.php ENDPATH**/ ?>