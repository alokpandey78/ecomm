<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-lg-10 col-xxl-8 mx-auto">
			<div class="card">
				<div class="card-header">
					<h3 class="h6 mb-0"><?php echo e(translate('Server information')); ?></h3>
				</div>
				<div class="card-body">
					<table class="table table-striped">
						<thead>
							<tr>
								<th><?php echo e(translate('Name')); ?></th>
								<th><?php echo e(translate('Current Version')); ?></th>
								<th><?php echo e(translate('Required Version')); ?></th>
								<th><?php echo e(translate('Status')); ?></th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>Php versions</td>
								<td><?php echo e(phpversion()); ?></td>
								<td>7.2 or 7.3</td>
								<td>
									<?php if((float)phpversion() > 7.2 && (float)phpversion() < 7.4): ?>
										<i class="las la-check text-success"></i>
									<?php else: ?>
										<i class="las la-times text-danger"></i>
									<?php endif; ?>
								</td>
							</tr>
							<tr>
								<td>MySQL</td>
								<td>
									<?php
										$results = DB::select( DB::raw("select version()") );
										$mysql_version =  $results[0]->{'version()'};
									?>
									<?php echo e($mysql_version); ?>

								</td>
								<td>5.6+</td>
								<td>
									<?php if($mysql_version >= 5.6): ?>
										<i class="las la-check text-success"></i>
									<?php else: ?>
										<i class="las la-times text-danger"></i>
									<?php endif; ?>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<div class="card">
				<div class="card-header">
					<h3 class="h6 mb-0"><?php echo e(translate('Extensions information')); ?></h3>
				</div>
				<div class="card-body">
					<table class="table table-striped">
						<thead>
							<tr>
								<th><?php echo e(translate('Extension Name')); ?></th>
								<th><?php echo e(translate('Status')); ?></th>
							</tr>
						</thead>
						<?php
							$loaded_extensions = get_loaded_extensions();
							$required_extensions = ['bcmath', 'ctype', 'json', 'mbstring', 'openssl', 'pdo', 'tokenizer', 'xml', 'dom', 'zip', 'curl', 'fileinfo', 'gd', 'pdo_mysql', 'pdo_mysqli']
						?>
						<tbody>
							<?php $__currentLoopData = $required_extensions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extension): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($extension); ?></td>
									<td>
										<?php if(in_array($extension, $loaded_extensions)): ?>
											<i class="las la-check text-success"></i>
										<?php else: ?>
											<i class="las la-times text-danger"></i>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
			<div class="card">
				<div class="card-header">
					<h3 class="h6 mb-0"><?php echo e(translate('Filesystem Permissions')); ?></h3>
				</div>
				<div class="card-body">
					<table class="table table-striped">
						<thead>
							<tr>
								<th><?php echo e(translate('File or Folder')); ?></th>
								<th><?php echo e(translate('Status')); ?></th>
							</tr>
						</thead>
						<?php
							$required_paths = ['.env', 'public', 'app/Providers', 'app/Http/Controllers', 'storage', 'resources/views']
						?>
						<tbody>
							<?php $__currentLoopData = $required_paths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($path); ?></td>
									<td>
										<?php if(is_writable(base_path($path))): ?>
											<i class="las la-check text-success"></i>
										<?php else: ?>
											<i class="las la-times text-danger"></i>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/backend/system/server_status.blade.php ENDPATH**/ ?>