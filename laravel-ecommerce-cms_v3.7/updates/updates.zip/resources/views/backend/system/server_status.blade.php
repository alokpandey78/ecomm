@extends('backend.layouts.app')

@section('content')
	<div class="row">
		<div class="col-lg-10 col-xxl-8 mx-auto">
			<div class="card">
				<div class="card-header">
					<h3 class="h6 mb-0">{{ translate('Server information') }}</h3>
				</div>
				<div class="card-body">
					<table class="table table-striped">
						<thead>
							<tr>
								<th>{{ translate('Name') }}</th>
								<th>{{ translate('Current Version') }}</th>
								<th>{{ translate('Required Version') }}</th>
								<th>{{ translate('Status') }}</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>Php versions</td>
								<td>{{ phpversion() }}</td>
								<td>7.2 or 7.3</td>
								<td>
									@if (floatval(phpversion()) >= 7.2 && floatval(phpversion()) < 7.4)
										<i class="las la-check text-success"></i>
									@else
										<i class="las la-times text-danger"></i>
									@endif
								</td>
							</tr>
							<tr>
								<td>MySQL</td>
								<td>
									@php
										$results = DB::select( DB::raw("select version()") );
										$mysql_version =  $results[0]->{'version()'};
									@endphp
									{{ $mysql_version }}
								</td>
								<td>5.6+</td>
								<td>
									@if ($mysql_version >= 5.6)
										<i class="las la-check text-success"></i>
									@else
										<i class="las la-times text-danger"></i>
									@endif
								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<div class="card">
				<div class="card-header">
					<h3 class="h6 mb-0">{{ translate('Extensions information') }}</h3>
				</div>
				<div class="card-body">
					<table class="table table-striped">
						<thead>
							<tr>
								<th>{{ translate('Extension Name') }}</th>
								<th>{{ translate('Status') }}</th>
							</tr>
						</thead>
						@php
							$loaded_extensions = get_loaded_extensions();
							$required_extensions = ['bcmath', 'ctype', 'json', 'mbstring', 'openssl', 'pdo', 'tokenizer', 'xml', 'dom', 'zip', 'curl', 'fileinfo', 'gd', 'pdo_mysql', 'pdo_mysqli']
						@endphp
						<tbody>
							@foreach ($required_extensions as $extension)
								<tr>
									<td>{{ $extension }}</td>
									<td>
										@if(in_array($extension, $loaded_extensions))
											<i class="las la-check text-success"></i>
										@else
											<i class="las la-times text-danger"></i>
										@endif
									</td>
								</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
			<div class="card">
				<div class="card-header">
					<h3 class="h6 mb-0">{{ translate('Filesystem Permissions') }}</h3>
				</div>
				<div class="card-body">
					<table class="table table-striped">
						<thead>
							<tr>
								<th>{{ translate('File or Folder') }}</th>
								<th>{{ translate('Status') }}</th>
							</tr>
						</thead>
						@php
							$required_paths = ['.env', 'public', 'app/Providers', 'app/Http/Controllers', 'storage', 'resources/views']
						@endphp
						<tbody>
							@foreach ($required_paths as $path)
								<tr>
									<td>{{ $path }}</td>
									<td>
										@if(is_writable(base_path($path)))
											<i class="las la-check text-success"></i>
										@else
											<i class="las la-times text-danger"></i>
										@endif
									</td>
								</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
@endsection
